package com.psl.training.service;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;

public class DBManager 
{
	static Connection conn = null;
	DBManager(){}
	
	public static Connection getConnection()
	{
		
		if(conn == null)
		{
			try
			{
				DriverManager.registerDriver(new com.mysql.jdbc.Driver());
				conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "root");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return conn;
	}
}
