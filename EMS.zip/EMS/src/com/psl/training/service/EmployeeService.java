package com.psl.training.service;

import java.util.List;

import com.psl.training.bean.Employee;
import com.psl.training.dao.EmployeeDao;

public class EmployeeService {
	EmployeeDao dao = new EmployeeDao();
	
	public List<Employee> getEmployees(){
		return dao.getAllEmployees();
	}
	
	public Employee getEmployeeById(int id){
		return dao.getEmployeeById(id);
	}
	
	public String addEmployee(Employee emp){
		return dao.addEmployee(emp);
	}
	
	public String addEmployeeToDB(Employee emp)
	{
		return dao.addEmployeeToDB(emp);
	}
	
	public List<Employee> getEmployeesFromDB()
	{
		return dao.getEmployeesFromDB();
	}
	
	public Employee getEmployeeFromDB(int id)
	{
		return dao.getEmployeeFromDB(id);
	}
	
	public String updateEmployeeFromDB(Employee emp)
	{
		return dao.updateEmployeeFromDB(emp);
	}
	
	public List<Employee> sortEmployeesByHireDate()
	{
		return dao.sortEmployeesByHireDate();
	}
	
	/*public static void main(String[] args) {
		EmployeeService ser = new EmployeeService();
		System.out.println(ser.getEmployeeFromDB(110));
	}*/
}
