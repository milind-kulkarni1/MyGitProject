package com.psl.training.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.psl.training.bean.Employee;
import com.psl.training.exceptions.EmployeeNotFoundException;
import com.psl.training.service.EmployeeService;

@Path("/ems")
public class EmployeeResource {
	EmployeeService ser = new EmployeeService();
	
/*	@GET
	@Path("/employees")
	public List<Employee> getEmployees(){
		return ser.getEmployees();
	}
	
	@GET
	@Path("/employees/{empId}")
	public Employee getEmployeeById(@PathParam("empId") int id){
		return ser.getEmployeeById(id);
	}
	
	
	@POST
	@Path("/employees")
	@Consumes(MediaType.APPLICATION_JSON)
	public String insertEmployee(Employee emp){
		return ser.addEmployee(emp);
	}*/
	
	@GET
	@Path("/employees/db")
	public List<Employee> getEmployees(){
		return ser.getEmployeesFromDB();
	}
	
	@GET
	@Path("/employees/db/{empId}")
	public Employee getEmployeeById(@PathParam("empId") int id){
		return ser.getEmployeeFromDB(id);
	}
	
	
	@POST
	@Path("/employees/db")
	@Consumes(MediaType.APPLICATION_JSON)
	public String insertEmployee(Employee emp){
		return ser.addEmployeeToDB(emp);
	}
	
	@PUT
	@Path("/employees/db")
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateEmployee(Employee emp){
		return ser.updateEmployeeFromDB(emp);
	}
	
	@GET
	@Path("/employees/db/sort")
	public List<Employee> sortEmployeeByHireDate(){
		return ser.sortEmployeesByHireDate();
	}
	
	@GET
	@Path("/employees/db/{format}/{id}")
	public Response getEmployeeInFormat(@PathParam("format") String format, @PathParam("id") int id)
	{
		Employee e = ser.getEmployeeFromDB(id);
		
		if(e == null)
			return Response.status(Status.OK).entity(new EmployeeNotFoundException().getMessage())
					.type(MediaType.TEXT_PLAIN).build();
		
		switch(format)
		{
			case "xml":
				return Response.status(Status.OK).entity(e).type(MediaType.APPLICATION_XML).build();
			case "json":
				return Response.status(Status.OK).entity(e).type(MediaType.APPLICATION_JSON).build();
			default:
				return Response.status(Status.NOT_ACCEPTABLE).type(MediaType.TEXT_PLAIN).entity("Not Found").build();
		}
	}
	
}
