package com.psl.training.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.psl.training.bean.Employee;
import com.psl.training.service.DBManager;

public class EmployeeDao {
	static List<Employee> empList = new ArrayList<>();
	Connection conn = DBManager.getConnection();
	static
	{
		empList.add(new Employee(101, "Milind", "Pune", 30000.00, "AD", Date.valueOf("2019-07-03")));
		empList.add(new Employee(102, "Vishal", "Mumbai", 45000.00, "SD", Date.valueOf("2019-06-04")));
	}
	
	public List<Employee> getAllEmployees()
	{
		return empList;
	}
	
	public Employee getEmployeeById(int id)
	{
		for(Employee e : empList)
			if(e.getEmpId() == id)
				return e;
		return null;
	}
	
	public String addEmployee(Employee e)
	{
		empList.add(e);
		return "Employee Added !!";
	}
	
	public void deleteEmployee(int id)
	{
		Employee rem = null;
		for(Employee e : empList)
			if(e.getEmpId() == id)
			{
				rem = e;
				break;
			}
		
		empList.remove(rem);
	}

	public String updateEmployee(Employee e)
	{
		for(Employee emp : empList)
			if(e.getEmpId() == emp.getEmpId())
			{
				emp.setCity(e.getCity());
				emp.setDept(e.getDept());
				emp.setEmpName(e.getEmpName());
				emp.setHireDate(e.getHireDate());
				emp.setSalary(e.getSalary());
				
				return "Updation Successful !!!";
			}
		return "Updation Failed !!!";
	}
	public String addEmployeeToDB(Employee emp)
	{
		String query = "insert into employee_tbl values ("+ emp.getEmpId() +",'"+ emp.getEmpName() +"','"+ 
		emp.getCity() +"',"+ emp.getSalary() +",'"+ emp.getDept() +"','"+ emp.getHireDate() +"')";
		Statement stmt;
		try
		{
			stmt = conn.createStatement();
			stmt.execute(query);
			return "Added Successfully";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "Add Failed";
		}
	}
	
	public List<Employee> getEmployeesFromDB()
	{
		String query = "select * from employee_tbl";
		Statement stmt;
		ResultSet rs;
		List <Employee> empList = new ArrayList<Employee>();
		
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while(rs.next())
			{
				empList.add(new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), 
						rs.getDouble(4), rs.getString(5), rs.getDate(6)));
			}
			return empList;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return empList;
		}
	}
	
	public Employee getEmployeeFromDB(int id)
	{
		String query = "select * from employee_tbl where empid=" + id;
		Statement stmt;
		ResultSet rs;
		Employee emp = null;
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			emp = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), 
						rs.getDouble(4), rs.getString(5), rs.getDate(6));
			return emp;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return emp;
		}
	}
	
	public String updateEmployeeFromDB(Employee emp)
	{
		String query = "update employee_tbl set empname='"+ emp.getEmpName() +"', city='"+ 
				emp.getCity() +"', salary="+ emp.getSalary() +", dept='"+ 
				emp.getDept() +"', hiredate='"+ emp.getHireDate() +"' where empid=" +emp.getEmpId();
		
		Statement stmt;
		try
		{
			stmt = conn.createStatement();
			stmt.executeUpdate(query);
			return "Updation Successful";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "Updation Failed";
		}
	}
	
	public List<Employee> sortEmployeesByHireDate()
	{
		List <Employee> empList = getEmployeesFromDB();
		Collections.sort(empList, new Comparator<Employee>() {

			@Override
			public int compare(Employee e1, Employee e2) {
				if(e1.getHireDate().equals(e2.getHireDate()))
					return 0;
				if(e1.getHireDate().before(e2.getHireDate()))
					return -1;
				return 1;
			}
		});
		return empList;
	}
	
	
}
