package com.psl.training.exceptions;

public class EmployeeNotFoundException extends Exception {
	@Override
	public String getMessage() {
		return "Employee Not Present In The Database !";
	}
	
	@Override
	public String toString() {
		return "Employee Not Present In The Database !";
	}
}
