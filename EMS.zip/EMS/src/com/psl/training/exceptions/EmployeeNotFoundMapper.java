package com.psl.training.exceptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@SuppressWarnings("serial")
@Provider
public class EmployeeNotFoundMapper extends Exception implements ExceptionMapper<EmployeeNotFoundException> {

	@Override
	public Response toResponse(EmployeeNotFoundException e) {
		// TODO Auto-generated method stub
		return Response.status(Status.OK).type(MediaType.TEXT_PLAIN).entity(e.getMessage()).build();
	}

}
